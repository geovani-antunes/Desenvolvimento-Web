<?php
$pdo = new PDO("mysql:host=mariadb;dbname=database;", "root", "mariadb"); //conexao com banco de dados